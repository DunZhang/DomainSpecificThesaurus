from ..semantic_related_word import SemanticRelatedWord
# from .SemanticRelatedWord import SemanticRelatedWord