from ..word_classification import WordClassification
# from .WordClassification import WordClassification,default_classify_func