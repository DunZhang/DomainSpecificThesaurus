

from DST.synonym_group.SynonymGroup import SynonymGroup

if __name__ =="__main__":
    sg= SynonymGroup(group_synonym_type="synonyms",domain_vocab=None)