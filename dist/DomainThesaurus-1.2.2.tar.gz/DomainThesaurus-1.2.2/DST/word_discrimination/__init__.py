from ..word_discrimination import WordDiscrimination
